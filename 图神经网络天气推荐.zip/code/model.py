import torch.nn as nn
from utils import *
from torch.nn import Module
import scipy.sparse as sp


class GCN_Layer(Module):
    ######################
    #    请你补充代码       #
    ######################


class GCN(Module):
    def __init__(self, args, user_feature, item_feature, rating):
        super(GCN, self).__init__()
        self.args = args
        self.device = args.device
        self.user_feature = user_feature
        self.item_feature = item_feature
        self.rating = rating
        self.num_user = rating['user_id'].max() + 1
        self.num_item = rating['item_id'].max() + 1
        # user embedding
        self.user_id_embedding = nn.Embedding(user_feature['id'].max() + 1, 32)
        self.user_age_embedding = nn.Embedding(user_feature['age'].max() + 1, 4)
        self.user_gender_embedding = nn.Embedding(user_feature['gender'].max() + 1, 2)
        self.user_occupation_embedding = nn.Embedding(user_feature['occupation'].max() + 1, 8)
        self.user_location_embedding = nn.Embedding(user_feature['location'].max() + 1, 18)
        # item embedding
        self.item_id_embedding = nn.Embedding(item_feature['id'].max() + 1, 32)
        self.item_type_embedding = nn.Embedding(item_feature['type'].max() + 1, 8)
        self.item_temperature_embedding = nn.Embedding(item_feature['temperature'].max() + 1, 8)
        self.item_humidity_embedding = nn.Embedding(item_feature['humidity'].max() + 1, 8)
        self.item_windSpeed_embedding = nn.Embedding(item_feature['windSpeed'].max() + 1, 8)
        # 自循环
        self.selfLoop = self.getSelfLoop(self.num_user + self.num_item)
        # 堆叠GCN层
        self.GCN_Layers = torch.nn.ModuleList()
        for _ in range(self.args.gcn_layers):
            self.GCN_Layers.append(GCN_Layer(self.args.embedSize, self.args.embedSize))
        self.graph = self.buildGraph()
        self.transForm = nn.Linear(in_features=self.args.embedSize * (self.args.gcn_layers + 1),
                                   out_features=self.args.embedSize)

    def getSelfLoop(self, num):
        i = torch.LongTensor(
            [[k for k in range(0, num)], [j for j in range(0, num)]])
        val = torch.FloatTensor([1] * num)
        return torch.sparse.FloatTensor(i, val).to(self.device)

    def buildGraph(self):
        ######################
        #    请你补充代码       #
        ######################

    def getFeature(self):
        # 根据用户特征获取对应的embedding
        user_id = self.user_id_embedding(torch.tensor(self.user_feature['id']).to(self.device))
        age = self.user_age_embedding(torch.tensor(self.user_feature['age']).to(self.device))
        gender = self.user_gender_embedding(torch.tensor(self.user_feature['gender']).to(self.device))
        occupation = self.user_occupation_embedding(torch.tensor(self.user_feature['occupation']).to(self.device))
        location = self.user_location_embedding(torch.tensor(self.user_feature['location']).to(self.device))
        user_emb = torch.cat((user_id, age, gender, occupation, location), dim=1)
        # 根据天气特征获取对应的embedding
        item_id = self.item_id_embedding(torch.tensor(self.item_feature['id']).to(self.device))
        item_type = self.item_type_embedding(torch.tensor(self.item_feature['type']).to(self.device))
        temperature = self.item_temperature_embedding(torch.tensor(self.item_feature['temperature']).to(self.device))
        humidity = self.item_humidity_embedding(torch.tensor(self.item_feature['humidity']).to(self.device))
        windSpeed = self.item_windSpeed_embedding(torch.tensor(self.item_feature['windSpeed']).to(self.device))
        item_emb = torch.cat((item_id, item_type, temperature, humidity, windSpeed), dim=1)
        # 拼接到一起
        concat_emb = torch.cat([user_emb, item_emb], dim=0)
        return concat_emb.to(self.device)

    def forward(self, users, items):
        ######################
        #    请你补充代码       #
        ######################
