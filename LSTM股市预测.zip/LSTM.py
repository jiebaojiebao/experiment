import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, Dataset


def read_dataset(dataset_type):
    assert dataset_type == "train" or dataset_type == "test"
    df = pd.read_csv('stock_market_price_{}.csv'.format(dataset_type))  # 读入股票数据
    data = np.array(df['close'])  # 获取收盘价序列
    data = data[::-1]  # 反转，使数据按照日期先后顺序排列

    normalize_data = (data - np.mean(data)) / np.std(data)  # 标准化
    normalize_data = normalize_data[:, np.newaxis]  # 增加维度
    X, y = [], []
    for i in range(len(normalize_data) - time_step):
        _x = normalize_data[i:i + time_step]
        _y = normalize_data[i + time_step]
        X.append(_x.tolist())
        y.append(_y.tolist())
    # plt.figure()
    # plt.plot(data)
    # plt.show() # 以折线图展示data
    return X, y


# 实验参数设置
time_step = 7    # 用前七天的数据预测第八天
hidden_size = 4  # 隐藏层维度
lstm_layers = 1  # 网络层数
batch_size = 64  # 每一批次训练多少个样例
input_size = 1   # 输入层维度
output_size = 1  # 输出层维度
lr = 0.05        # 学习率


class myDataset(Dataset):
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def __getitem__(self, index):
        return torch.Tensor(self.x[index]), torch.Tensor(self.y[index])

    def __len__(self):
        return len(self.x)


class LSTM(nn.Module):
    def __init__(self, input_size, output_size, hidden_size, device):
        super(LSTM, self).__init__()
        ###########
        # 请你补充代码
        ###########

    def init_lstm_state(self, batch_size):
        ###########
        # 请你补充代码
        ###########

    def forward(self, seq):
        ###########
        # 请你补充代码
        ###########


X_train, y_train = read_dataset('train')
X_test, y_test = read_dataset('test')
train_dataset = myDataset(X_train, y_train)
test_dataset = myDataset(X_test, y_test)
train_loader = DataLoader(train_dataset, batch_size, shuffle=True)
test_loader = DataLoader(test_dataset, 1)

# 设定训练轮数
num_epochs = 50
device = torch.device('cuda') if torch.cuda.is_available() else torch.device('cpu')
hist = np.zeros(num_epochs)
model = LSTM(input_size, output_size, hidden_size, device)
# 定义优化器和损失函数
optimiser = torch.optim.Adam(model.parameters(), lr=lr)  # 使用Adam优化算法
loss_func = torch.nn.MSELoss(reduction='mean')  # 使用均方差作为损失函数
for epoch in range(num_epochs):
    epoch_loss = 0
    for i, data in enumerate(train_loader):
        X, y = data
        pred_y, _ = model(X.to(device))
        loss = loss_func(pred_y, y.to(device))
        optimiser.zero_grad()
        loss.backward()
        optimiser.step()
        epoch_loss += loss.item()
    print("Epoch ", epoch, "MSE: ", epoch_loss)
    hist[epoch] = epoch_loss
plt.plot(hist)
plt.show()

# 测试
model.eval()
result = []
for i, data in enumerate(test_loader):
    X, y = data
    pred_y, _ = model(X.to(device))
    result.append(pred_y.item())

plt.plot(range(len(y_test)), y_test, label="true_y", color="blue")
plt.plot(range(len(result)), result, label="pred_y", color="red")
plt.legend(loc='best')
plt.show()
